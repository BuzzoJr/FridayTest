@extends("admin.layouts.default")
@section('breadcrumbs')@endsection
@section('pageTitle')
    <h1>{{ trans('admiko.home') }}</h1>
@endsection
@section('pageInfo')@endsection
@section('backBtn')@endsection
@section('content')
@endsection
