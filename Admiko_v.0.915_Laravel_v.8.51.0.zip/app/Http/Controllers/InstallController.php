<?php
/** Installation for backend login. **/

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\Admin\AdmikoHelperTrait;
use App\Models\Admin\Admins\Admins;
use App\Models\Admin\Admins\AdminRoles;
use Illuminate\Support\Facades\DB;
use File;

class InstallController extends Controller
{
    use AdmikoHelperTrait;

    public function index()
    {
        Artisan::call('key:generate');
        return redirect('install');
    }

    public function install()
    {
        return view('install');
    }

    public function db_save(Request $request)
    {
        $this->validator($request);
        if (config('database.default') == 'mysql') {
            //todo: setup connections for other database types!!!!!!
            config(['database.connections.mysql.host' => $request->db_host]);
            config(['database.connections.mysql.database' => $request->db_table]);
            config(['database.connections.mysql.username' => $request->db_user]);
            config(['database.connections.mysql.password' => $request->db_password]);
        } else {
            return redirect()->back()->withInput()->with('error', 'Unsupported database type!');
        }
        try {
            DB::connection()->getPdo();
            if (DB::connection()->getDatabaseName()) {
                $data = [
                    'APP_URL'     => URL::to('/'),
                    'DB_HOST'     => $request->db_host,
                    'DB_DATABASE' => $request->db_table,
                    'DB_USERNAME' => $request->db_user,
                    'DB_PASSWORD' => $request->db_password,
                ];
                $defaults = [env("APP_URL"), env("DB_HOST"), env("DB_DATABASE"), env("DB_USERNAME"), env("DB_PASSWORD")];
                $path = base_path('.env');
                $content = file_get_contents($path);
                $i = 0;
                foreach ($data as $key => $value) {
                    $content = str_replace($key . '=' . $defaults[$i], $key . '=' . $value, $content);
                    $i++;
                }
                File::put(base_path() . '/.env', $content);
                $tableData[] = array("table" => "admins", "timeStamp" => 1, "tableFields" => array("name" => "string", "email" => "stringUnique", "password" => "string", "image" => "binary", "theme" => "string100", "role_id" => "integer", "remember_token" => "string100", "reset_token" => "string100"));
                $tableData[] = array("table" => "admins_roles", "timeStamp" => 1, "tableFields" => array("title" => "string"));
                $tableData[] = array("table" => "admins_roles_permission", "timeStamp" => 0, "tableFields" => array("role_id" => "foreignId", "permission" => "string"), "tableForeignKeys" => array("role_id" => array("parentTable" => "admins_roles", "key_name" => "fk_admins_roles")));
                $tableData[] = array("table" => "admiko_auditable_logs", "timeStamp" => 1, "tableFields" => array("action" => "string", "row_id" => "bigIntegerNullable", "model" => "string", "user_id" => "bigIntegerNullable", "info" => "text", "url" => "text", "ip" => "string"));
                $tableData[] = array("table" => "admins_multi_tenancy_access", "timeStamp" => 0, "tableFields" => array("parent_id" => "foreignId", "selected_id" => "bigIntegerUnsigned"), "tableForeignKeys" => array("parent_id" => array("parentTable" => "admins", "key_name" => "fk_admiko_multi_tenancy_admins")));


                $this->setupDatabase($tableData,false);
                $data['name'] = $request->name??$request->email;
                $data['email'] = $request->email;
                $data['password'] = $request->password;
                $data['theme'] = 'admiko';
                $avatar = file_get_contents(base_path('public/assets/admiko/images/').'avatar.jpg');
                $base64 = base64_encode($avatar);
                $data['image'] = 'data:image/jpeg;base64,'.$base64;
                $data['role_id'] = 1;
                Admins::create($data);
                AdminRoles::create(['id' => 1, 'title' => 'Developer']);
                AdminRoles::create(['id' => 2, 'title' => 'User']);
                File::delete(base_path('routes') . '/web.php');
                File::move(base_path('routes') . '/web_original.php', base_path('routes') . '/web.php');
                File::delete(base_path('resources/views') . '/install.blade.php');
                File::delete(base_path('app/Http/Controllers') . '/InstallController.php');
                File::delete(base_path('resources/lang/en') . '/install.php');
                return redirect('admin');
            } else {
                return redirect()->back()->withInput()->with('error', trans('install.db_error'));
            }
        } catch (\Exception $e) {
            return redirect()->back()->withInput()->with('error', trans('install.db_error'));
        }
    }

    private function validator(Request $request)
    {
        //validation rules.
        $rules = [
            'email'    => 'required|email|min:5|max:100',
            'password' => 'required|string|min:6|max:100',
            'db_host'  => 'required|string|min:1|max:100',
            'db_table' => 'required|string|min:1|max:100',
            'db_user'  => 'required|string|min:1|max:100',
        ];
        $request->validate($rules);
    }
}
