<?php
/** Admiko version file **/

/**
 * This file will be overwritten on update. Don't add your code here!
 */
return [
    'project_key'             => '5114f81889a77d55e1cd7560ea37b378a6892fd44f985e85c1',
    'version'             => 0.915
];
